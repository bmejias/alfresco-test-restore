package brussels.bric.alfresco.alfresco.gdpr;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Random;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;


/**
 * @since 
 * @author jbaltus
 *
 */
@SpringBootApplication
public class Application implements CommandLineRunner {

    private static final Logger LOG = LoggerFactory.getLogger(Application.class);

    public static void main(String args[]) {
        SpringApplication.run(Application.class, args);
    }

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Override
    public void run(String... strings) throws Exception {
    	LOG.debug("Change all lastnames with random values...");
        changeProperties("lastName");

        LOG.debug("Change all firstnames with random values...");
        changeProperties("firstName");
    }
    
    
    public void changeProperties(String key) {
    	List<User> users = jdbcTemplate.query(
                "select * from alf_node_properties where qname_id in (select id from alf_qname where local_name like ?)",
                new UserRowMapper(), key
            );
    	
    	Random r = new Random();
    	int Low = 0;
    	int High = users.size();
    	
    	for (User user : users) {
    		int indice = r.nextInt(High-Low) + Low;
			jdbcTemplate.update("update alf_node_properties set string_value = ? where node_id = ?;", users.get(indice).getValue(), user.getId());
		}
    }
    
    /**
     * ROW MAPPER
     * @author jbaltus
     *
     */
    public class UserRowMapper implements RowMapper<User>{
        public User mapRow(ResultSet rs, int rowNum) throws SQLException {
            User user = new User();
            user.setId(rs.getLong("node_id"));
            user.setValue(rs.getString("string_value"));
            return user;
        }
    }
}